package com.aboushanab.chemistrylab

import android.content.Context
import android.content.Intent
import android.view.View
import android.view.View.inflate
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.res.ColorStateListInflaterCompat.inflate
import androidx.core.content.res.ComplexColorCompat.inflate
import androidx.core.graphics.drawable.DrawableCompat.inflate
import androidx.recyclerview.widget.RecyclerView
import com.aboushanab.chemistrylab.TypeClasses.Element
import kotlinx.android.synthetic.main.single_element_layout.view.*
import kotlinx.android.synthetic.main.activity_main.*
import java.util.zip.Inflater

class ElementsAdapter(val places: MutableList<Element>, val passElement: PassElement) :
    RecyclerView.Adapter<ElementsAdapter.ViewHolder>() {
    interface PassElement {
        fun onClickElement(elementPassed: Element)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ElementsAdapter.ViewHolder(parent.inflate(R.layout.single_element_layout))
    }


    override fun getItemCount(): Int {
        return places.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(places[position], passElement)
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        private lateinit var element: Element
        var passElement: PassElement? = null

        init {
            itemView.setOnClickListener(this)
        }

        fun bind(element: Element, passElement: PassElement) {
            this.element = element
            this.passElement = passElement
            itemView.element_name.setTextColor(itemView.resources.getColor(element.color))
            itemView.element_name.text = element.abb
            itemView.element_name.setShadowLayer(4F,2F,2F,R.color.black)
            when (element.type) {
                1 -> itemView.element_container_image.setImageResource(R.drawable.solid_container)
                2 -> itemView.element_container_image.setImageResource(R.drawable.liquid_container)
                3 -> itemView.element_container_image.setImageResource(R.drawable.gas_container)
            }

        }

        override fun onClick(view: View) {
            passElement?.onClickElement(element)
        }
    }
}

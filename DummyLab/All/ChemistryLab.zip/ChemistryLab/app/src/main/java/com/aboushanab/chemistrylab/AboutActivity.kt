package com.aboushanab.chemistrylab

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_about.*
class AboutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
        textView1.text="Dummy Lab\n1.0 \nBy- KARTIK GUPTA"
        textView2.text="As each of us navigates the impact of COVID-19 on our lives, I hope that you are at your home," +
                "due to the lockdown\n\nI have created this virtual chemistry lab so that the learning never stops!" +
                "\n\nYou can mail me at cyberkartik@gmail.com for any further clarifications or bugs in the\n" +
                "application if any."
        textView3.text="www.dummylabs.com\n\nwww.facebook.com/dummylabs"
        textView4.text="Copyright@2020 dummy labs"
    }
}

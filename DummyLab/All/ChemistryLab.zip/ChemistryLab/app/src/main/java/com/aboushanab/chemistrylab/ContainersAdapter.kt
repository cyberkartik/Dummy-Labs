package com.aboushanab.chemistrylab

import android.content.Intent
import android.graphics.BitmapFactory
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.aboushanab.chemistrylab.TypeClasses.Container
import kotlinx.android.synthetic.main.single_container_layout.view.*

class ContainersAdapter (val containers: MutableList<Container>, val passContainer: PassContainer) :
    RecyclerView.Adapter<ContainersAdapter.ViewHolder>() {
    interface PassContainer {
        fun onClickContainer(containerPassed: Container)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ContainersAdapter.ViewHolder(parent.inflate(R.layout.single_container_layout))
    }


    override fun getItemCount(): Int {
        return containers.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(containers[position],passContainer)
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        private lateinit var container: Container
        var passContainer: PassContainer? = null
        init {
            itemView.setOnClickListener(this)
        }

        fun bind(container: Container,passContainer: PassContainer) {
            this.container = container
            this.passContainer = passContainer
            val context = itemView.context
            val options = BitmapFactory.Options()
            options.inSampleSize = 2
            val mBitmapSampled = BitmapFactory.decodeResource(context.resources, container.image, options)
            itemView.container_list_image.setImageBitmap(mBitmapSampled)
        }

        override fun onClick(view: View) {
            passContainer?.onClickContainer(container)
        }
    }
}
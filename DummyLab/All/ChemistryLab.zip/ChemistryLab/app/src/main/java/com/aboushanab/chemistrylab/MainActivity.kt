package com.aboushanab.chemistrylab

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import android.widget.Toast.LENGTH_SHORT
import androidx.core.graphics.drawable.toDrawable
import androidx.recyclerview.widget.LinearLayoutManager
import com.aboushanab.chemistrylab.TypeClasses.Container
import com.aboushanab.chemistrylab.TypeClasses.Element
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.single_element_layout.*

class MainActivity : AppCompatActivity() {

    var containers: ArrayList<Container> = ArrayList()
    var solidElements: ArrayList<Element> = ArrayList()
    var liquidElements: ArrayList<Element> = ArrayList()
    var gasElements: ArrayList<Element> = ArrayList()
    var currentElement: Element = Element("Ag", 1, R.color.silver, "Ag")
    var currentContainer: Container =
        Container("Default", arrayListOf(), R.drawable.liquid_container)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initializeLayoutManager()

        addSolidElements(solidElements)
        addLiquidElements(liquidElements)
        addGasElements(gasElements)
        addContainers(containers)
        solid_button.setOnClickListener {
            elements_recyclerView.adapter =
                ElementsAdapter(solidElements, object : ElementsAdapter.PassElement {
                    override fun onClickElement(elementPassed: Element) {
                        currentElement = elementPassed
                        selected_textView.text = elementPassed.name
                    }
                })
        }
        liquid_button.setOnClickListener {
            elements_recyclerView.adapter =
                ElementsAdapter(liquidElements, object : ElementsAdapter.PassElement {
                    override fun onClickElement(elementPassed: Element) {
                        currentElement = elementPassed
                        selected_textView.text = elementPassed.name
                    }
                })
        }
        gas_button.setOnClickListener {
            elements_recyclerView.adapter =
                ElementsAdapter(gasElements, object : ElementsAdapter.PassElement {
                    override fun onClickElement(elementPassed: Element) {
                        currentElement = elementPassed
                        selected_textView.text = elementPassed.name
                    }
                })
        }
        containers_recyclerview.adapter =
            ContainersAdapter(containers, object : ContainersAdapter.PassContainer {
                override fun onClickContainer(containerPassed: Container) {
                    container_image.setImageResource(containerPassed.image)
                }
            })

        var webSettings: WebSettings = webview.settings
        webSettings.javaScriptEnabled = true
        webSettings.allowContentAccess = true
        webSettings.setAppCacheEnabled(true)
        webSettings.domStorageEnabled = true
        webSettings.useWideViewPort = true
        webview.webViewClient = WebViewClient()
        webSettings.allowContentAccess
        var ziad: String = "https://chemequations.com/en/?s="
        var ziad2:String = ""
        enter_button.setOnClickListener {
            if (currentContainer.contents.size == 4) {
                Toast.makeText(this, "Sorry container is full", LENGTH_SHORT).show()
            } else {
                when (currentContainer.contents.size) {
                    0 -> {
                        ziad2=ziad+currentElement.abb+"&ref=input"
                        currentContainer.contents.add(currentElement)
                        contents_text.append(currentElement.abb)
                        color1.visibility = View.VISIBLE
                        color1.setBackgroundColor(this.resources.getColor(currentElement.color))
                    }
                    1 -> {
                        ziad2=ziad+currentContainer.contents[0].abb+"%2B"+currentElement.abb+"&ref=input"
                        currentContainer.contents.add(currentElement)
                        contents_text.append("+" + currentElement.abb)
                        color2.visibility = View.VISIBLE
                        color2.setBackgroundColor(this.resources.getColor(currentElement.color))
                    }
                    2 -> {
                        ziad2=ziad+currentContainer.contents[0].abb+"%2B"+currentContainer.contents[1].abb+"%2B"+currentElement.abb+"&ref=input"
                        currentContainer.contents.add(currentElement)
                        contents_text.append("+" + currentElement.abb)
                        color3.visibility = View.VISIBLE
                        color3.setBackgroundColor(this.resources.getColor(currentElement.color))
                    }
                    3 -> {
                        ziad2=ziad+currentContainer.contents[0].abb+"%2B"+currentContainer.contents[1].abb+"%2B"+currentElement.abb+"%2B"+currentElement.abb+"&ref=input"
                        currentContainer.contents.add(currentElement)
                        contents_text.append("+" + currentElement.abb)
                        color4.visibility = View.VISIBLE
                        color4.setBackgroundColor(this.resources.getColor(currentElement.color))
                    }
                }
            }
        }
        clear_button.setOnClickListener {
            currentContainer.contents.clear()
            color1.visibility = View.INVISIBLE
            color2.visibility = View.INVISIBLE
            color3.visibility = View.INVISIBLE
            color4.visibility = View.INVISIBLE
            contents_text.text = "Contents: "
            ziad2=""
        }
        about_button.setOnClickListener {
            openAbout()
        }



        start_button.setOnClickListener {
            webview.loadUrl(ziad2)
        }
    }

    private fun addSolidElements(elements: ArrayList<Element>) {
        elements.add(
            Element(
                "Silver",
                1,
                R.color.silver,
                "Ag"
            )
        )

        elements.add(
            Element(
                "Silver(I) oxide",
                1,
                R.color.black,
                "Ag2O"
            )
        )

        elements.add(
            Element(
                "Silver sulfide",
                1,
                R.color.black,
                "Ag2S"
            )
        )

        elements.add(
            Element(
                "Silver sulfate",
                1,
                R.color.black,
                "Ag2SO4"
            )
        )

        elements.add(
            Element(
                "Silver bromide",
                1,
                R.color.yellow,
                "AgBr"
            )
        )

        elements.add(
            Element(
                "Silver chloride",
                1,
                R.color.white,
                "AgCl"
            )
        )

        elements.add(
            Element(
                "Silver(I) fluoride",
                1,
                R.color.yellow,
                "AgF"
            )
        )

        elements.add(
            Element(
                "Silver iodide",
                1,
                R.color.yellow,
                "AgI"
            )
        )

        elements.add(
            Element(
                "Silver Nitrate",
                1,
                R.color.white,
                "AgNO3"
            )
        )

        elements.add(
            Element(
                "Aluminium",
                1,
                R.color.silver,
                "Al"
            )
        )

        elements.add(
            Element(
                "Aluminium oxide",
                1,
                R.color.white,
                "Al2O3"
            )
        )

        elements.add(
            Element(
                "Aluminum sulfide",
                1,
                R.color.gray,
                "Al2S3"
            )
        )

        elements.add(
            Element(
                "Aluminium sulfate",
                1,
                R.color.white,
                "Al2(SO4)3"
            )
        )

        elements.add(
            Element(
                "Aluminum bromide",
                1,
                R.color.white,
                "AlBr3"
            )
        )

        elements.add(
            Element(
                "Aluminium chloride",
                1,
                R.color.yellow,
                "AlCl3"
            )
        )

        elements.add(
            Element(
                "Aluminium nitrate",
                1,
                R.color.white,
                "Al(NO3)3"
            )
        )

        elements.add(
            Element(
                "Aluminium hydroxide",
                1,
                R.color.white,
                "Al(OH)3"
            )
        )

        elements.add(
            Element(
                "Arsenic",
                1,
                R.color.gray,
                "As"
            )
        )

        elements.add(
            Element(
                "Arsenic trioxide",
                1,
                R.color.blue,
                "As4O6"
            )
        )

        elements.add(
            Element(
                "Arsenic iodide",
                1,
                R.color.red,
                "AsI3"
            )
        )

        elements.add(
            Element(
                "Gold",
                1,
                R.color.gold,
                "Au"
            )
        )

        elements.add(
            Element(
                "Barium",
                1,
                R.color.silver,
                "Ba"
            )
        )

        elements.add(
            Element(
                "Barium chloride",
                1,
                R.color.white,
                "BaCl2"
            )
        )

        elements.add(
            Element(
                "Barium carbonate",
                1,
                R.color.white,
                "BaCO3"
            )
        )

        elements.add(
            Element(
                "Barium nitrate",
                1,
                R.color.colorless,
                "Ba(NO3)2"
            )
        )

        elements.add(
            Element(
                "Barium oxide",
                1,
                R.color.white,
                "BaO"
            )
        )

        elements.add(
            Element(
                "Barium hydroxide",
                1,
                R.color.white,
                "Ba(OH)2"
            )
        )

        elements.add(
            Element(
                "Barium sulfate",
                1,
                R.color.white,
                "BaSO4"
            )
        )

        elements.add(
            Element(
                "Carbon",
                1,
                R.color.black,
                "C"
            )
        )

        elements.add(
            Element(
                "Calcium",
                1,
                R.color.silver,
                "Ca"
            )
        )

        elements.add(
            Element(
                "Calcium carbide",
                1,
                R.color.white,
                "CaC2"
            )
        )

        elements.add(
            Element(
                "Calcium chloride",
                1,
                R.color.white,
                "CaCl2"
            )
        )

        elements.add(
            Element(
                "Calcium carbonate",
                1,
                R.color.white,
                "CaCO3"
            )
        )

        elements.add(
            Element(
                "Calcium nitrate",
                1,
                R.color.colorless,
                "Ca(NO3)2"
            )
        )

        elements.add(
            Element(
                "Calcium oxide",
                1,
                R.color.white,
                "CaO"
            )
        )

        elements.add(
            Element(
                "Calcium hydroxide",
                1,
                R.color.colorless,
                "Ca(OH)2"
            )
        )

        elements.add(
            Element(
                "Calcium sulfite",
                1,
                R.color.white,
                "CaSO3"
            )
        )

        elements.add(
            Element(
                "Calcium sulfate",
                1,
                R.color.white,
                "CaSO4"
            )
        )

        elements.add(
            Element(
                "Cobalt",
                1,
                R.color.gray,
                "Co"
            )
        )

        elements.add(
            Element(
                "Chromium",
                1,
                R.color.silver,
                "Cr"
            )
        )

        elements.add(
            Element(
                "Caesium",
                1,
                R.color.silver,
                "Cs"
            )
        )

        elements.add(
            Element(
                "Copper",
                1,
                R.color.brown,
                "Cu"
            )
        )

        elements.add(
            Element(
                "Copper(I) oxide",
                1,
                R.color.red,
                "Cu2O"
            )
        )

        elements.add(
            Element(
                "Copper(I) sulfide",
                1,
                R.color.black,
                "Cu2S"
            )
        )

        elements.add(
            Element(
                "Copper(II) chloride",
                1,
                R.color.brown,
                "CuCl2"
            )
        )

        elements.add(
            Element(
                "Copper carbonate",
                1,
                R.color.green,
                "CuCO3"
            )
        )

        elements.add(
            Element(
                "Copper(II) nitrate",
                1,
                R.color.blue,
                "Cu(NO3)2"
            )
        )

        elements.add(
            Element(
                "Copper(II) oxide",
                1,
                R.color.black,
                "CuO"
            )
        )

        elements.add(
            Element(
                "Copper(II) hydroxide",
                1,
                R.color.blue,
                "Cu(OH)2"
            )
        )

        elements.add(
            Element(
                "Copper(II) sulfate",
                1,
                R.color.blue,
                "CuSO4"
            )
        )

        elements.add(
            Element(
                "Iron",
                1,
                R.color.green,
                "Fe"
            )
        )

        elements.add(
            Element(
                "Iron(III) oxide",
                1,
                R.color.brown,
                "Fe2O3"
            )
        )

        elements.add(
            Element(
                "Iron(III) sulfate",
                1,
                R.color.yellow,
                "Fe2(SO4)3"
            )
        )

        elements.add(
            Element(
                "Iron(II,III) oxide",
                1,
                R.color.black,
                "Fe3O4"
            )
        )

        elements.add(
            Element(
                "Iron(II) chloride",
                1,
                R.color.white,
                "FeCl2"
            )
        )

        elements.add(
            Element(
                "Iron(III) chloride",
                1,
                R.color.green,
                "FeCl3"
            )
        )

        elements.add(
            Element(
                "Iron(II) Nitrate",
                1,
                R.color.violet,
                "Fe(NO3)2"
            )
        )

        elements.add(
            Element(
                "Iron(III) nitrate",
                1,
                R.color.violet,
                "Fe(NO3)3"
            )
        )

        elements.add(
            Element(
                "Iron(II) oxide",
                1,
                R.color.black,
                "FeO"
            )
        )

        elements.add(
            Element(
                "Iron(II) hydroxide",
                1,
                R.color.white,
                "Fe(OH)2"
            )
        )

        elements.add(
            Element(
                "Iron(III) oxide-hydroxide",
                1,
                R.color.orange,
                "Fe(OH)3"
            )
        )

        elements.add(
            Element(
                "Iron(II) sulfate",
                1,
                R.color.green,
                "FeSO4"
            )
        )

        elements.add(
            Element(
                "Phosphoric acid",
                1,
                R.color.colorless,
                "H3PO4"
            )
        )

        elements.add(
            Element(
                "Mercury(II) nitrate",
                1,
                R.color.white,
                "Hg(NO3)2"
            )
        )

        elements.add(
            Element(
                "Mercury(II) oxide",
                1,
                R.color.red,
                "HgO"
            )
        )

        elements.add(
            Element(
                "Iodine",
                1,
                R.color.purple,
                "I2"
            )
        )

        elements.add(
            Element(
                "Potassium",
                1,
                R.color.silver,
                "K"
            )
        )

        elements.add(
            Element(
                "Potassium manganate",
                1,
                R.color.green,
                "K2MnO4"
            )
        )

        elements.add(
            Element(
                "Potassium oxide",
                1,
                R.color.yellow,
                "K2O"
            )
        )

        elements.add(
            Element(
                "Potassium sulfate",
                1,
                R.color.white,
                "K2SO4"
            )
        )

        elements.add(
            Element(
                "Potassium chloride",
                1,
                R.color.colorless,
                "KCl"
            )
        )

        elements.add(
            Element(
                "Potassium chlorate",
                1,
                R.color.white,
                "KClO3"
            )
        )


        elements.add(
            Element(
                "Potassium hydride",
                1,
                R.color.white,
                "KH"
            )
        )

        elements.add(
            Element(
                "Potassium iodide",
                1,
                R.color.white,
                "KI"
            )
        )

        elements.add(
            Element(
                "Potassium permanganate",
                1,
                R.color.black,
                "KMnO4"
            )
        )

        elements.add(
            Element(
                "Potassium Nitrate",
                1,
                R.color.white,
                "KNO3"
            )
        )

        elements.add(
            Element(
                "Potassium hydroxide",
                1,
                R.color.colorless,
                "KOH"
            )
        )

        elements.add(
            Element(
                "Lithium",
                1,
                R.color.white,
                "Li"
            )
        )

        elements.add(
            Element(
                "Lithium oxide",
                1,
                R.color.white,
                "Li2O"
            )
        )

        elements.add(
            Element(
                "Lithium nitride",
                1,
                R.color.pink,
                "Li3N"
            )
        )

        elements.add(
            Element(
                "Lithium hydroxide",
                1,
                R.color.white,
                "LiOH"
            )
        )

        elements.add(
            Element(
                "Magnesium",
                1,
                R.color.white,
                "Mg"
            )
        )

        elements.add(
            Element(
                "Magnesium nitride",
                1,
                R.color.yellow,
                "Mg3N2"
            )
        )

        elements.add(
            Element(
                "Magnesium chloride",
                1,
                R.color.colorless,
                "MgCl2"
            )
        )

        elements.add(
            Element(
                "Magnesium nitrate",
                1,
                R.color.white,
                "Mg(NO3)2"
            )
        )

        elements.add(
            Element(
                "Magnesium oxide",
                1,
                R.color.white,
                "MgO"
            )
        )

        elements.add(
            Element(
                "Magnesium hydroxide",
                1,
                R.color.white,
                "Mg(OH)2"
            )
        )

        elements.add(
            Element(
                "Magnesium sulfate",
                1,
                R.color.white,
                "MgSO4"
            )
        )

        elements.add(
            Element(
                "Manganese",
                1,
                R.color.white,
                "Mn"
            )
        )

        elements.add(
            Element(
                "Manganese(II) chloride",
                1,
                R.color.pink,
                "MnCl2"
            )
        )

        elements.add(
            Element(
                "Manganese(IV) oxide",
                1,
                R.color.brown,
                "MnO2"
            )
        )

        elements.add(
            Element(
                "Manganese(II) sulfate",
                1,
                R.color.brown,
                "MnSO2"
            )
        )

        elements.add(
            Element(
                "Sodium",
                1,
                R.color.white,
                "Na"
            )
        )

        elements.add(
            Element(
                "Sodium carbonate",
                1,
                R.color.white,
                "Na2CO3"
            )
        )

        elements.add(
            Element(
                "Sodium oxide",
                1,
                R.color.white,
                "Na2O"
            )
        )

        elements.add(
            Element(
                "Sodium peroxide",
                1,
                R.color.yellow,
                "Na2O2"
            )
        )

        elements.add(
            Element(
                "Sodium sulfite",
                1,
                R.color.yellow,
                "Na2SO3"
            )
        )

        elements.add(
            Element(
                "Sodium sulfate",
                1,
                R.color.white,
                "Na2SO4"
            )
        )

        elements.add(
            Element(
                "Sodium aluminate",
                1,
                R.color.white,
                "NaAlO2"
            )
        )

        elements.add(
            Element(
                "Sodium bromide",
                1,
                R.color.white,
                "NaBr"
            )
        )

        elements.add(
            Element(
                "Sodium acetate",
                1,
                R.color.white,
                "NaC2H3O2"
            )
        )

        elements.add(
            Element(
                "Sodium chloride",
                1,
                R.color.colorless,
                "NaCl"
            )
        )

        elements.add(
            Element(
                "Sodium bicarbonate",
                1,
                R.color.white,
                "NaHCO3"
            )
        )

        elements.add(
            Element(
                "Sodium Bisulfate",
                1,
                R.color.white,
                "NaHSO4"
            )
        )

        elements.add(
            Element(
                "Sodium nitrate",
                1,
                R.color.white,
                "NaNO3"
            )
        )

        elements.add(
            Element(
                "Sodium hydroxide",
                1,
                R.color.colorless,
                "NaOh"
            )
        )

        elements.add(
            Element(
                "Ammonium carbonate",
                1,
                R.color.colorless,
                "(NH4)2CO3"
            )
        )

        elements.add(
            Element(
                "Ammonium Sulfate",
                1,
                R.color.colorless,
                "(NH4)2SO4"
            )
        )

        elements.add(
            Element(
                "Ammonium chloride",
                1,
                R.color.white,
                "NH4Cl"
            )
        )

        elements.add(
            Element(
                "Ammonium nitrate",
                1,
                R.color.white,
                "NH4NO3"
            )
        )

        elements.add(
            Element(
                "Nickel",
                1,
                R.color.gray,
                "Ni"
            )
        )

        elements.add(
            Element(
                "Nitrogen Tri-iodide",
                1,
                R.color.purple,
                "NI3"
            )
        )

        elements.add(
            Element(
                "Phosphorus",
                1,
                R.color.white,
                "P"
            )
        )

        elements.add(
            Element(
                "Phosphorus pentoxide",
                1,
                R.color.white,
                "P2O5"
            )
        )

        elements.add(
            Element(
                "Lead",
                1,
                R.color.white,
                "Pb"
            )
        )

        elements.add(
            Element(
                "Lead(II) chloride",
                1,
                R.color.white,
                "PbCl2"
            )
        )

        elements.add(
            Element(
                "Lead(II) nitrate",
                1,
                R.color.colorless,
                "Pb(NO3)2"
            )
        )

        elements.add(
            Element(
                "Lead(II) oxide",
                1,
                R.color.red,
                "PbO"
            )
        )

        elements.add(
            Element(
                "Lead(IV) oxide",
                1,
                R.color.brown,
                "PbO2"
            )
        )

        elements.add(
            Element(
                "Lead(II) sulfate",
                1,
                R.color.white,
                "PbSO4"
            )
        )

        elements.add(
            Element(
                "Platinum",
                1,
                R.color.gray,
                "Pt"
            )
        )

        elements.add(
            Element(
                "Sulfur",
                1,
                R.color.yellow,
                "S"
            )
        )

        elements.add(
            Element(
                "Silicon",
                1,
                R.color.silver,
                "Si"
            )
        )

        elements.add(
            Element(
                "Zinc",
                1,
                R.color.silver,
                "Zn"
            )
        )

        elements.add(
            Element(
                "Zinc chloride",
                1,
                R.color.colorless,
                "ZnCl2"
            )
        )

        elements.add(
            Element(
                "Zinc nitrate",
                1,
                R.color.white,
                "Zn(NO3)2"
            )
        )

        elements.add(
            Element(
                "Zinc peroxide",
                1,
                R.color.yellow,
                "ZnO2"
            )
        )

        elements.add(
            Element(
                "Zinc sulphate",
                1,
                R.color.white,
                "ZnSo4"
            )
        )

    }

    private fun addLiquidElements(elements: ArrayList<Element>) {

        elements.add(
            Element(
                "Blue",
                2,
                R.color.blue,
                "Blue"
            )
        )

        elements.add(
            Element(
                "Bromine",
                2,
                R.color.red,
                "Br2"
            )
        )

        elements.add(
            Element(
                "Green",
                2,
                R.color.green,
                "Green"
            )
        )

        elements.add(
            Element(
                "Water",
                2,
                R.color.colorless,
                "H2o"
            )
        )

        elements.add(
            Element(
                "Hydrogen peroxide",
                2,
                R.color.blue,
                "H2O2"
            )
        )

        elements.add(
            Element(
                "Sulfurous acid",
                2,
                R.color.colorless,
                "H2SO3"
            )
        )

        elements.add(
            Element(
                "Sulfuric acid",
                2,
                R.color.yellow,
                "H2SO4"
            )
        )

        elements.add(
            Element(
                "Hydrochloric acid",
                2,
                R.color.colorless,
                "HCl"
            )
        )

        elements.add(
            Element(
                "Hydrogen fluoride",
                2,
                R.color.colorless,
                "HF"
            )
        )

        elements.add(
            Element(
                "Mercury",
                2,
                R.color.silver,
                "Hg"
            )
        )

        elements.add(
            Element(
                "Nitric acid",
                2,
                R.color.colorless,
                "HNO3"
            )
        )

        elements.add(
            Element(
                "Litmus",
                2,
                R.color.red,
                "Litmus"
            )
        )

        elements.add(
            Element(
                "Mint",
                2,
                R.color.colorless,
                "Mint"
            )
        )

        elements.add(
            Element(
                "Ammonium Hydroxide",
                2,
                R.color.blue,
                "NH4OH"
            )
        )

        elements.add(
            Element(
                "Orange",
                2,
                R.color.orange,
                "Orange"
            )
        )

        elements.add(
            Element(
                "Purple",
                2,
                R.color.purple,
                "Purple"
            )
        )

        elements.add(
            Element(
                "Sulfur trioxide",
                2,
                R.color.colorless,
                "SO3"
            )
        )

        elements.add(
            Element(
                "White",
                2,
                R.color.white,
                "White"
            )
        )

        elements.add(
            Element(
                "Yellow",
                2,
                R.color.yellow,
                "Yellow"
            )
        )
    }

    private fun addGasElements(elements: ArrayList<Element>) {
        elements.add(
            Element(
                "Argon",
                3,
                R.color.violet,
                "Ar"
            )
        )

        elements.add(
            Element(
                "Chlorine",
                3,
                R.color.yellow,
                "Cl2"
            )
        )

        elements.add(
            Element(
                "Carbon monoxide",
                3,
                R.color.colorless,
                "CO"
            )
        )

        elements.add(
            Element(
                "Carbon dioxide",
                3,
                R.color.colorless,
                "Co2"
            )
        )

        elements.add(
            Element(
                "Fluorine",
                3,
                R.color.yellow,
                "F2"
            )
        )

        elements.add(
            Element(
                "Hydrogen",
                3,
                R.color.colorless,
                "H2"
            )
        )

        elements.add(
            Element(
                "Hydrogen sulfide",
                3,
                R.color.colorless,
                "H2S"
            )
        )

        elements.add(
            Element(
                "Hydrogen bromide",
                3,
                R.color.colorless,
                "HBr"
            )
        )

        elements.add(
            Element(
                "Helium",
                3,
                R.color.colorless,
                "He"
            )
        )

        elements.add(
            Element(
                "Nitrogen",
                3,
                R.color.colorless,
                "N2"
            )
        )

        elements.add(
            Element(
                "Nitrous oxide",
                3,
                R.color.colorless,
                "N2O"
            )

        )
        elements.add(
            Element(
                "Neon",
                3,
                R.color.colorless,
                "Ne"
            )
        )

        elements.add(
            Element(
                "Ammonia",
                3,
                R.color.colorless,
                "NH3"
            )
        )

        elements.add(
            Element(
                "Nitric oxide",
                3,
                R.color.colorless,
                "NO"
            )
        )

        elements.add(
            Element(
                "Nitrogen dioxide",
                3,
                R.color.brown,
                "no2"
            )
        )

        elements.add(
            Element(
                "Oxygen",
                3,
                R.color.colorless,
                "O2"
            )
        )
        elements.add(
            Element(
                "Ozone",
                3,
                R.color.colorless,
                "O3"
            )
        )

        elements.add(
            Element(
                "Sulfur dioxide",
                3,
                R.color.colorless,
                "SO2"
            )
        )
    }

    private fun addContainers(containers: ArrayList<Container>) {
        containers.add(
            Container(
                "Flask1",
                arrayListOf(),
                R.drawable.liquid_container
            )
        )

        containers.add(
            Container(
                "Flask2",
                arrayListOf(),
                R.drawable.flask2
            )
        )

        containers.add(
            Container(
                "Flask3",
                arrayListOf(),
                R.drawable.solid_container
            )
        )
    }

    private fun initializeLayoutManager() {
        container_image.setImageResource(R.drawable.liquid_container)
        containers_recyclerview.layoutManager = LinearLayoutManager(
            this,
            LinearLayoutManager.HORIZONTAL, false
        )
        elements_recyclerView.layoutManager = LinearLayoutManager(
            this,
            LinearLayoutManager.HORIZONTAL, false
        )
    }

    private fun openAbout() {
        var intent = Intent(this, AboutActivity::class.java)
        this.startActivity(intent)
    }

}

package com.aboushanab.chemistrylab.TypeClasses

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class Element(val name:String , val type:Int,val color:Int , val abb:String):
    Parcelable
package com.aboushanab.chemistrylab.TypeClasses

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class Container(
    val name: String,
    val contents: ArrayList<Element>,
    val image: Int
) :
    Parcelable